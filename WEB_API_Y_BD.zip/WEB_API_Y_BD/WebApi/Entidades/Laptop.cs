﻿namespace WebApi.Entidades
{
    public class Laptop
    {
        public int Id { get; set; }
        public required string Name { get; set; }
    }
}
